from huggingface_hub import snapshot_download

# Define the repository ID and target directory
repo_id = "risunobushi/catvton_model_lib"
local_dir = "F:/CUi/ComfyUI_windows_portable/ComfyUI/models/CatVTON"

# Download the entire model library to the specified directory
snapshot_download(repo_id, local_dir=local_dir)
